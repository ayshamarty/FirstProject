
public class Runner {
	static int num1 = 2;
	static int num2 = 4;
	static String myString;
	static String s1;
	static String s2;
	static String operator;

	public static void main(String[] args) {

		// Ex 1 Hello World
		System.out.println("Hello World!");

		// Ex 2 hard coded calculator
		calculator1();

		// Ex 2 calculator with parameters
		addition(5, 4);

		subtraction(6, 10);

		multiplication(7, 3);
		// another way of returning division, the above methods work too
		System.out.println(division(5, 2));

		// Ex 3a checking strings
		// matching
		checkString1("This is my string");
		// not matching
		checkString1("Hello");

		// Ex 3b
		// not matching
		checkString2("yes", "no");
		// matching
		checkString2("no", "no");

		// Ex 4 calculator continued
		// unrecognised parameters
		calculatorCont(10, "&", 3);
		// valid parameters
		calculatorCont(10, "/", 3);

		// calculator continued but with switch statements rather than if statements
		calculatorContSwitch(15, "/", 18);
		calculatorContSwitch(15, "6", 18);

		// Ex5 iteration
		printNumbers1();
		printNumbers2();
		printNumbersUnits();

	}

	private static void calculator1() {

		System.out.println(num1 + num2);

	}

	private static void addition(int num1, int num2) {
		System.out.print(num1);
		System.out.print(" + ");
		System.out.print(num2);
		System.out.print(" = ");
		System.out.println(num1 + num2);
	}

	private static void subtraction(int num1, int num2) {
		System.out.print(num1);
		System.out.print(" - ");
		System.out.print(num2);
		System.out.print(" = ");
		System.out.println(num1 - num2);

	}

	private static void multiplication(int num1, int num2) {
		System.out.print(num1);
		System.out.print(" * ");
		System.out.print(num2);
		System.out.print(" = ");
		System.out.println(num1 * num2);
	}

	private static double division(double num1, double num2) {
		System.out.print(num1);
		System.out.print(" / ");
		System.out.print(num2);
		System.out.print(" = ");
		return num1 / num2;
	}

	private static void checkString1(String myString) {
		if (myString.equals("This is my string")) {
			System.out.println(myString);
		} else {
			System.out.println("This is not my string");
		}

	};

	private static void checkString2(String s1, String s2) {
		if (s1.equals(s2)) {
			System.out.println("These strings are the same");
		} else {
			System.out.println("These strings are not the same");
		}
	}

	private static void calculatorCont(double num1, String operator, double num2) {
		if (operator == "+") {
			System.out.print(num1);
			System.out.print(" + ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 + num2);
		} else if (operator == "-") {
			System.out.print(num1);
			System.out.print(" - ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 - num2);
		} else if (operator == "*") {
			System.out.print(num1);
			System.out.print(" * ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 * num2);
		} else if (operator == "/") {
			System.out.print(num1);
			System.out.print(" / ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 / num2);
		} else {
			System.out.println("input not recognised");
		}
	}

	private static void calculatorContSwitch(double num1, String operator, double num2) {
		switch (operator) {
		case "+":
			System.out.print(num1);
			System.out.print(" + ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 + num2);
			break;
		case "-":
			System.out.print(num1);
			System.out.print(" - ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 - num2);
			break;
		case "*":
			System.out.print(num1);
			System.out.print(" * ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 * num2);
			break;
		case "/":
			System.out.print(num1);
			System.out.print(" / ");
			System.out.print(num2);
			System.out.print(" = ");
			System.out.println(num1 / num2);
			break;
		default:
			System.out.println("input not recognised");
			break;
		}

	}

	private static void printNumbers1() {
		for (int i = 1; i < 11; i++) {
			System.out.print(i);
		}
	}

	private static void printNumbers2() {
		for (int i = 100; i < 1000; i++) {
			System.out.print(i);
		}
	}

	private static void printNumbersUnits() {
		for (int i = 1; i < 20; i++) {
			switch (i) {
			case 1:
				System.out.print("\nOne ");
				break;
			case 2:
				System.out.print("Two ");
				break;
			case 3:
				System.out.print("Three ");
				break;
			case 4:
				System.out.print("Four ");
				break;
			case 5:
				System.out.print("Five ");
				break;
			case 6:
				System.out.print("Six ");
				break;
			case 7:
				System.out.print("Seven ");
				break;
			case 8:
				System.out.print("Eight ");
				break;
			case 9:
				System.out.print("Nine ");
				break;
			case 10:
				System.out.print("Ten ");
				break;
			case 11:
				System.out.print("Eleven ");
				break;
			case 12:
				System.out.print("Twelve ");
				break;
			case 13:
				System.out.print("Thirteen ");
				break;
			case 14:
				System.out.print("Fourteen ");
				break;
			case 15:
				System.out.print("Fifteen ");
				break;
			case 16:
				System.out.print("Sixteen ");
				break;
			case 17:
				System.out.print("Seventeen ");
				break;
			case 18:
				System.out.print("Eighteen ");
				break;
			case 19:
				System.out.print("Nineteen ");
				break;

			}
		}
	}

}
